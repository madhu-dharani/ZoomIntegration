import Button from "../Button";
import { Card } from "../Card/Card";
import CustomAccordian from "../CustomAccordian";
import { ZoomMeet } from "../ZoomMeet";

const Screen12 = ({ nextHandler }) => {
  return (
    <>
      <ZoomMeet />
      <CustomAccordian accordianTitle={"General"}>
        <Card className="bg-lime-400">
          <p>/"UnDecider/"" please share your takeaways</p>
          <p>Timer 2:00</p>
        </Card>
      </CustomAccordian>

      <CustomAccordian accordianTitle={"Specific Instructions "}>
        <Card className="bg-yellow-500 bg-green-500">
          <p>Moderrator:</p>
          <p>
            say:Thank you all now let's hear from ""/UnDecider/"" about takeaways from <br />
            the conversation
          </p>
          <Button>START TIMER</Button>
          <p>after the sharing click </p>
          <Button onClick={nextHandler}>Next</Button>
        </Card>
      </CustomAccordian>
    </>
  );
};
export default Screen12;

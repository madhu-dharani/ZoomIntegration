import React from "react";

export const ZoomMeet = () => {
  return <div className="max-h-1/2">Zoom Meet</div>;
};
